#!/usr/bin/env bash
# smb-mount.sh - Idempotent SMB auto-mount for ASIAGO workstation.
# Invoked by ~/Library/LaunchAgents/com.asiago.mount-smb-shares.plist.
# Design: docs/plans/2026-04-16-smb-mount-rebuild-design.md

set -uo pipefail

SCRIPT_NAME="$(basename "${BASH_SOURCE[0]}")"
# Must match StandardOutPath in com.asiago.mount-smb-shares.plist.
LOG_FILE="${HOME}/.local/state/com.asiago.mount-smb-shares.log"

# Parallel arrays — each index defines one share.
# Fields: server | user | share_path (SHARE/subpath...) | mount_point | op_ref
# op_ref can be:
#   "op://..."  → fetch password from 1Password, mount with user:pass in URL
#   ""          → use keychain (Apple ID SSO / stored credential) via bare URL
SHARE_SERVERS=(
  "romano.local"
  "mimolette.local"
)
SHARE_USERS=(
  "dsadmin"
  ""
)
SHARE_PATHS=(
  "DSMedia/Archives/ASIAGO/archives"
  "extra-vieille/Workspaces"
)
SHARE_MOUNTS=(
  "${HOME}/Downloads/archives"
  "${HOME}/workspaces"
)
SHARE_OP_REFS=(
  "op://Personal/Synology NAS - dsadmin/password"
  ""
)

log() {
  local ts
  ts="$(date '+%Y-%m-%d %H:%M:%S')"
  printf '%s [%s] %s\n' "${ts}" "${SCRIPT_NAME}" "$*"
}

# Percent-encode every character that isn't a URL-safe unreserved char.
url_encode() {
  local s="$1"
  local i c out=""
  for ((i = 0; i < ${#s}; i += 1)); do
    c="${s:i:1}"
    case "${c}" in
      [a-zA-Z0-9.~_-]) out+="${c}" ;;
      *) out+="$(printf '%%%02X' "'${c}")" ;;
    esac
  done
  printf '%s' "${out}"
}

# True if $1 is currently a mount point for any smbfs mount.
# Uses grep -F for a literal mount-point match so paths with regex
# metacharacters (., +, [, etc.) don't broaden the match.
is_mounted() {
  local mp="$1"
  mount | grep -qF " on ${mp} (smbfs"
}

# True if anything at all (any fstype) is currently mounted at $1.
any_mount_at() {
  local mp="$1"
  mount | grep -qF " on ${mp} ("
}

# Make sure the mount point is a directory ready to receive a mount.
prepare_mount_point() {
  local mp="$1"
  if any_mount_at "${mp}"; then
    log "Detaching stale mount at ${mp}"
    local umount_err
    if ! umount_err="$(umount "${mp}" 2>&1)"; then
      log "  warning: umount failed (${umount_err}); mount_smbfs may report Device busy"
    fi
  fi
  if [[ -e "${mp}" && ! -d "${mp}" ]]; then
    log "Removing non-directory at mount point: ${mp}"
    rm -f "${mp}"
  fi
  if [[ ! -e "${mp}" ]]; then
    log "Creating mount point: ${mp}"
    mkdir -p "${mp}"
  fi
}

mount_one() {
  local server="$1"
  local user="$2"
  local share_path="$3"
  local mp="$4"
  local op_ref="$5"

  local auth_label
  if [[ -n "${op_ref}" ]]; then
    auth_label="${user}@ (op)"
  else
    auth_label="(keychain)"
  fi
  log "Processing ${auth_label} //${server}/${share_path} -> ${mp}"

  if is_mounted "${mp}"; then
    log "  already mounted, skipping"
    return 0
  fi

  prepare_mount_point "${mp}"

  if ! ping -c 1 -W 2000 "${server}" >/dev/null 2>&1; then
    log "  unreachable (ping failed): ${server}"
    return 1
  fi

  local url
  if [[ -n "${op_ref}" ]]; then
    local pw
    if ! pw="$(op read "${op_ref}" 2>&1)"; then
      log "  op read failed for ${op_ref}: ${pw}"
      return 1
    fi
    if [[ -z "${pw}" ]]; then
      log "  op read returned empty password for ${op_ref}"
      return 1
    fi
    local enc_user enc_pw
    enc_user="$(url_encode "${user}")"
    enc_pw="$(url_encode "${pw}")"
    url="//${enc_user}:${enc_pw}@${server}/${share_path}"
  else
    url="//${server}/${share_path}"
  fi

  local mount_err
  if mount_err="$(mount_smbfs -N "${url}" "${mp}" 2>&1)"; then
    log "  mount_smbfs succeeded"
  else
    # enc_pw is only set in op mode above; the :- default lets keychain-mode
    # shares (which have no password to scrub) skip the substitution cleanly.
    if [[ -n "${enc_pw:-}" ]]; then
      mount_err="${mount_err//${enc_pw}/REDACTED}"
    fi
    log "  mount_smbfs failed: ${mount_err}"
    return 1
  fi

  if ! is_mounted "${mp}"; then
    log "  verification failed: ${mp} not in mount table"
    return 1
  fi
  log "  verified mounted"
  return 0
}

main() {
  # Reset per-run log so it can't grow unbounded. Launchd holds this file in
  # append mode, so writes after truncate correctly resume at position 0.
  : >"${LOG_FILE}" 2>/dev/null || true

  log "Starting SMB mount pass (${#SHARE_SERVERS[@]} shares configured)"

  local failures=0
  local i
  for ((i = 0; i < ${#SHARE_SERVERS[@]}; i += 1)); do
    if ! mount_one \
      "${SHARE_SERVERS[i]}" \
      "${SHARE_USERS[i]}" \
      "${SHARE_PATHS[i]}" \
      "${SHARE_MOUNTS[i]}" \
      "${SHARE_OP_REFS[i]}"; then
      failures=$((failures + 1))
    fi
  done

  if ((failures > 0)); then
    log "Finished with ${failures} failure(s)"
    return 1
  fi
  log "Finished, all shares mounted"
  return 0
}

main "$@"
