#!/usr/bin/env bash
# One-shot verification of the smb-mount keychain fallback fix
# (smartwatermelon/scripts PR #66, merged 2026-04-24).
#
# Launched once by ~/Library/LaunchAgents/com.andrewrich.smb-mount-checkup.plist
# on 2026-05-01 ~09:15 local. Writes a summary to ~/Desktop and posts a macOS
# notification only if any check fails. Self-unloads after running.

set -uo pipefail

OUT_DIR="${HOME}/Desktop"
OUT_FILE="${OUT_DIR}/smb-mount-checkup-$(date '+%Y%m%d').txt"
LOG_FILE="${HOME}/.local/state/com.asiago.mount-smb-shares.log"
ALERT_FILE="${HOME}/.local/state/smb-mount-alert.txt"
LABEL="com.andrewrich.smb-mount-checkup"

mkdir -p "${OUT_DIR}"

fail_count=0
note() { printf '%s\n' "$*" >>"${OUT_FILE}"; }

run_ts="$(date '+%Y-%m-%d %H:%M:%S %Z')"
{
  printf '=== smb-mount keychain fallback check-in ===\n'
  printf 'Run:  %s\n' "${run_ts}"
  printf 'PR:   smartwatermelon/scripts#66 (merged 2026-04-24)\n\n'
} >"${OUT_FILE}"

# Check 1: alert sentinel should be absent
note '## Check 1: alert sentinel file'
if [[ -f "${ALERT_FILE}" ]]; then
  note "FAIL: ${ALERT_FILE} exists — active alert content:"
  sed 's/^/  /' "${ALERT_FILE}" >>"${OUT_FILE}"
  fail_count=$((fail_count + 1))
else
  note "OK: ${ALERT_FILE} is absent (no active alert)."
fi
note ""

# Check 2: recent smb-mount runs finish cleanly
note '## Check 2: recent smb-mount run log'
if [[ ! -f "${LOG_FILE}" ]]; then
  note "FAIL: ${LOG_FILE} does not exist."
  fail_count=$((fail_count + 1))
elif grep -q "Finished, all shares mounted" "${LOG_FILE}" 2>/dev/null; then
  note "OK: log shows a recent 'Finished, all shares mounted' line."
  note "Last 10 log lines:"
  tail -10 "${LOG_FILE}" | sed 's/^/  /' >>"${OUT_FILE}"
else
  note "FAIL: log does not show a successful mount in its current contents."
  note "Last 20 log lines:"
  tail -20 "${LOG_FILE}" | sed 's/^/  /' >>"${OUT_FILE}"
  fail_count=$((fail_count + 1))
fi
note ""

# Check 3: op invocation rate should be low (not per-minute overnight)
note '## Check 3: op invocation rate over last 24h'
log_show_output=$(log show --predicate 'process == "op"' --last 24h 2>&1)
log_show_status=$?
if ((log_show_status != 0)); then
  note "FAIL: 'log show' exited ${log_show_status} — check could not run (permission denied?)."
  note "log show output:"
  printf '%s\n' "${log_show_output}" | sed 's/^/  /' >>"${OUT_FILE}"
  fail_count=$((fail_count + 1))
else
  count=$(printf '%s\n' "${log_show_output}" | grep -c "Retrieve User by ID" || true)
  count=${count:-0}
  # Threshold picked to sit well above normal daytime op usage and well below
  # the pre-fix bug rate (~2500/day from 60/min overnight retry loops).
  threshold=500
  note "Count: ${count} (threshold: ${threshold})"
  if ((count > threshold)); then
    note "FAIL: ${count} > ${threshold}. May indicate the overnight retry loop is back."
    fail_count=$((fail_count + 1))
  else
    note "OK: invocation rate below threshold."
  fi
fi
note ""

if ((fail_count == 0)); then
  note "## Result: fix holding, no action needed."
else
  note "## Result: ${fail_count} check(s) failed. Investigate manually."
  note ""
  note "Suggested next steps:"
  note "  1. Read this file top-to-bottom for specifics."
  note "  2. tail -50 ${LOG_FILE}"
  note "  3. log show --predicate 'process == \"op\"' --last 25h | less"
  note "  4. Open tracking issue on smartwatermelon/scripts if fix regressed."
  osascript \
    -e "display notification \"See ${OUT_FILE}\" with title \"smb-mount checkup: ${fail_count} failure(s)\"" \
    >/dev/null 2>&1 || true
fi

# Self-unload: remove this one-shot LaunchAgent. The plist file stays on
# disk but is no longer scheduled. User may delete it and this script
# manually once they've read the result file.
launchctl bootout "gui/$(id -u)/${LABEL}" 2>/dev/null || true
