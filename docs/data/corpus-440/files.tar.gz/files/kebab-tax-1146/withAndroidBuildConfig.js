/**
 * Expo Config Plugin for Android Production Build Configuration
 *
 * Preserves critical production build settings that would otherwise be lost
 * when running `expo prebuild --clean`.
 *
 * Configured settings:
 * - ProGuard/R8 code obfuscation and optimization
 * - Release signing configuration (EAS Build + local env vars)
 * - Custom ProGuard rules for React Native, Expo, and dependencies
 * - Signing validation logic for local builds
 * - Network security configuration (enforces HTTPS-only, prevents cleartext traffic)
 *
 * Related: Issue #260, Issue #175, Issue #196
 */

const {
  withGradleProperties,
  withAppBuildGradle,
  withDangerousMod,
  withAndroidManifest,
} = require('@expo/config-plugins');
const fs = require('fs');
const path = require('path');

/**
 * Main plugin function - applies all Android build configuration
 */
function withAndroidBuildConfig(config) {
  // TESTING: Set to true to COMPLETELY DISABLE ProGuard (for debugging)
  const DISABLE_PROGUARD = process.env.DISABLE_PROGUARD === 'true';

  if (DISABLE_PROGUARD) {
    console.warn('⚠️  ProGuard COMPLETELY DISABLED (DISABLE_PROGUARD=true)');
    console.warn('⚠️  This is for TESTING ONLY - DO NOT use for production');
  }

  // Step 1: Configure gradle.properties
  config = withGradleProperties(config, config => {
    // Enable ProGuard/R8 minification and resource shrinking for release builds
    // UNLESS explicitly disabled for debugging
    config.modResults.push({
      type: 'property',
      key: 'android.enableMinifyInReleaseBuilds',
      value: DISABLE_PROGUARD ? 'false' : 'true',
    });
    config.modResults.push({
      type: 'property',
      key: 'android.enableShrinkResourcesInReleaseBuilds',
      value: DISABLE_PROGUARD ? 'false' : 'true',
    });

    return config;
  });

  // Step 2: Configure build.gradle
  config = withAppBuildGradle(config, config => {
    let buildGradle = config.modResults.contents;

    // Inject EAS Build integration at the top (after plugin applies)
    const easBuildIntegration = `
// EAS Build will inject signing configuration via eas-build.gradle (generated during build)
def easGradle = new File(project.projectDir, "eas-build.gradle")
if (easGradle.exists()) {
    apply from: easGradle
}
`;

    // Insert EAS Build integration after plugin declarations
    if (!buildGradle.includes('eas-build.gradle')) {
      const beforeLength = buildGradle.length;
      buildGradle = buildGradle.replace(
        /apply plugin: "com\.facebook\.react"/,
        `apply plugin: "com.facebook.react"${easBuildIntegration}`
      );
      if (buildGradle.length === beforeLength) {
        throw new Error(
          'Failed to inject EAS Build integration - build.gradle format may have changed. ' +
            'Please check that "com.facebook.react" plugin is declared.'
        );
      }
    }

    // Configure release signing with environment variable support
    const releaseSigningConfig = `
        release {
            // Production keystore configuration from environment variables
            // If not provided, EAS Build will inject credentials via eas-build.gradle
            def keystorePath = System.getenv("KEBAB_RELEASE_KEYSTORE_PATH")
            def keystorePass = System.getenv("KEBAB_RELEASE_KEYSTORE_PASSWORD")
            def releaseKeyAlias = System.getenv("KEBAB_RELEASE_KEY_ALIAS")
            def releaseKeyPassword = System.getenv("KEBAB_RELEASE_KEY_PASSWORD")

            // Only configure if local credentials are provided
            // Note: File existence is validated at build time (not config time)
            // to avoid blocking debug builds when keystore env vars are set
            if (keystorePath && keystorePass && releaseKeyAlias && releaseKeyPassword) {
                storeFile file(keystorePath)
                storePassword keystorePass
                keyAlias releaseKeyAlias
                keyPassword releaseKeyPassword
            }
            // If no local credentials, EAS Build will populate this via eas-build.gradle
        }`;

    // Add release signing config if it doesn't exist
    if (!buildGradle.includes('KEBAB_RELEASE_KEYSTORE_PATH')) {
      const beforeLength = buildGradle.length;
      buildGradle = buildGradle.replace(
        /(signingConfigs\s*\{[\s\S]*?debug\s*\{[\s\S]*?\})/,
        `$1${releaseSigningConfig}`
      );
      if (buildGradle.length === beforeLength) {
        throw new Error(
          'Failed to inject release signing config - build.gradle format may have changed. ' +
            'Please check that signingConfigs block with debug config exists.'
        );
      }
    }

    // FIX #286: Use STANDARD ProGuard mode (not optimized)
    // proguard-android-optimize.txt causes expo-sqlite crashes on Android
    // Standard mode provides sufficient obfuscation without breaking Kotlin type converters
    const proguardOptimizeMatches = buildGradle.match(
      /getDefaultProguardFile\("proguard-android-optimize\.txt"\)/g
    );
    buildGradle = buildGradle.replace(
      /getDefaultProguardFile\("proguard-android-optimize\.txt"\)/g,
      'getDefaultProguardFile("proguard-android.txt")'
    );
    if (proguardOptimizeMatches && proguardOptimizeMatches.length > 0) {
      console.log(
        `✓ Migrated ProGuard to standard mode (${proguardOptimizeMatches.length} occurrence(s))`
      );
    }

    // Fix buildTypes.release to use signingConfigs.release instead of debug
    // Expo's default uses debug signing for release builds, which is insecure
    const beforeSigningFix = buildGradle.length;
    buildGradle = buildGradle.replace(
      /(buildTypes\s*\{[\s\S]*?release\s*\{[\s\S]*?)signingConfig\s+signingConfigs\.debug/,
      '$1// EAS Build will inject signingConfig via eas-build.gradle\n            // For local builds with production credentials, signingConfigs.release is configured above\n            signingConfig signingConfigs.release'
    );
    if (buildGradle.length === beforeSigningFix) {
      console.warn(
        '⚠️  Failed to fix release signing config - may already be correct or format changed'
      );
    }

    // Add signing validation for local release builds
    const signingValidation = `
// Validate signing configuration before release builds
// Only validates local builds - EAS Build handles credentials automatically
gradle.taskGraph.whenReady { graph ->
    if (graph.hasTask(':app:packageRelease') || graph.hasTask(':app:bundleRelease')) {
        def easGradleExists = new File(project.projectDir, "eas-build.gradle").exists()

        // Skip validation for EAS builds - credentials are injected by EAS
        if (easGradleExists) {
            println "✓ EAS Build detected - signing credentials will be injected by EAS"
            return
        }

        // For local builds, require environment variables and validate keystore file
        def releaseConfig = android.signingConfigs.release
        def localCredsConfigured = releaseConfig.storeFile != null

        if (!localCredsConfigured) {
            throw new GradleException(
                """
                ============================================================
                ERROR: Release signing configuration not found
                ============================================================

                Local release builds require signing credentials via environment variables:

                export KEBAB_RELEASE_KEYSTORE_PATH=/path/to/keystore
                export KEBAB_RELEASE_KEYSTORE_PASSWORD=your_password
                export KEBAB_RELEASE_KEY_ALIAS=your_alias
                export KEBAB_RELEASE_KEY_PASSWORD=your_key_password

                For EAS builds, use: eas build --platform android
                ============================================================
                """.stripIndent()
            )
        }

        // Validate that the keystore file actually exists
        if (releaseConfig.storeFile && !releaseConfig.storeFile.exists()) {
            throw new GradleException(
                """
                ============================================================
                ERROR: Keystore file not found
                ============================================================

                The keystore file does not exist at: \${releaseConfig.storeFile.absolutePath}

                Please verify KEBAB_RELEASE_KEYSTORE_PATH points to a valid keystore file.

                For EAS builds, use: eas build --platform android
                ============================================================
                """.stripIndent()
            )
        }
    }
}
`;

    // Add signing validation if it doesn't exist
    if (!buildGradle.includes('gradle.taskGraph.whenReady')) {
      buildGradle += '\n' + signingValidation;
    }

    config.modResults.contents = buildGradle;
    return config;
  });

  // Step 3: Preserve custom ProGuard rules
  config = withDangerousMod(config, [
    'android',
    async config => {
      const proguardRulesPath = path.join(
        config.modRequest.platformProjectRoot,
        'app',
        'proguard-rules.pro'
      );

      // Read the comprehensive ProGuard rules from plugins directory
      // This file is preserved outside android/ to survive expo prebuild --clean
      const sourceProguardPath = path.join(
        config.modRequest.projectRoot,
        'plugins',
        'proguard-rules.pro'
      );

      if (fs.existsSync(sourceProguardPath)) {
        const customRules = fs.readFileSync(sourceProguardPath, 'utf-8');
        fs.writeFileSync(proguardRulesPath, customRules, 'utf-8');
        console.log('✓ Preserved custom ProGuard rules (211 lines)');
      } else {
        console.warn('⚠️  Source ProGuard rules not found at plugins/proguard-rules.pro');
      }

      return config;
    },
  ]);

  // Step 4: Increase Gradle wrapper download timeout
  // EAS build servers frequently time out downloading Gradle distributions
  // with the default 10s timeout on a 137MB file. Bump to 120s.
  config = withDangerousMod(config, [
    'android',
    async config => {
      const wrapperPropsPath = path.join(
        config.modRequest.platformProjectRoot,
        'gradle',
        'wrapper',
        'gradle-wrapper.properties'
      );

      if (fs.existsSync(wrapperPropsPath)) {
        let content = fs.readFileSync(wrapperPropsPath, 'utf-8');
        content = content.replace(
          /networkTimeout=\d+/,
          'networkTimeout=120000'
        );
        fs.writeFileSync(wrapperPropsPath, content, 'utf-8');
        console.log('✓ Gradle wrapper networkTimeout set to 120s');
      }

      return config;
    },
  ]);

  // Step 5: Add network security configuration (Issue #196)
  // Enforces HTTPS-only communication and prevents cleartext traffic
  config = withDangerousMod(config, [
    'android',
    async config => {
      // Create res/xml directory if it doesn't exist
      const resXmlDir = path.join(
        config.modRequest.platformProjectRoot,
        'app',
        'src',
        'main',
        'res',
        'xml'
      );

      // ROBUSTNESS FIX: Wrap fs operations in try-catch for better error messages
      try {
        if (!fs.existsSync(resXmlDir)) {
          fs.mkdirSync(resXmlDir, { recursive: true });
        }
      } catch (error) {
        throw new Error(
          `Failed to create network security config directory at ${resXmlDir}.\n` +
            `Error: ${error.message}\n` +
            'This may indicate a permissions issue or disk space problem.'
        );
      }

      const networkSecurityConfigPath = path.join(resXmlDir, 'network_security_config.xml');

      // Determine environment based on APP_VARIANT
      // SECURITY: Fail-secure - only development and staging get cleartext exceptions
      // Beta builds are distributed to external testers and MUST use production security
      const DEVELOPMENT_VARIANTS = ['development', 'staging'];
      const appVariant = process.env.APP_VARIANT || config.extra?.appVariant;
      const isDevelopment = DEVELOPMENT_VARIANTS.includes(appVariant);

      // Warn if APP_VARIANT is not set - fail-secure to production config
      if (!appVariant) {
        console.warn(
          '⚠️  APP_VARIANT not set - defaulting to PRODUCTION security config (strict HTTPS-only). ' +
            'Set APP_VARIANT=development or APP_VARIANT=staging for cleartext exceptions.'
        );
      }

      let networkSecurityConfig;

      if (!isDevelopment) {
        // PRODUCTION/BETA: Strict HTTPS-only, no cleartext exceptions
        // Applies to: production, beta, and any unknown variants (fail-secure)
        networkSecurityConfig = `<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <base-config cleartextTrafficPermitted="false">
        <trust-anchors>
            <certificates src="system" />
        </trust-anchors>
    </base-config>
</network-security-config>
`;
        console.log(
          `✓ Network security config: ${appVariant || 'DEFAULT'} mode (strict HTTPS-only)`
        );
      } else {
        // DEVELOPMENT/STAGING ONLY: Allow localhost for development API access
        // Extract dev host from DEV_API_URL if it's an HTTP URL (HTTPS doesn't need cleartext)
        const devApiUrl = process.env.DEV_API_URL;
        let devHost = '';
        let devHostDisplayName = '';

        if (devApiUrl) {
          try {
            const url = new URL(devApiUrl);

            // SECURITY: Validate hostname is in standard format BEFORE normalization
            // Node's URL constructor normalizes exotic IP notations:
            // - Hex: 0xc0.0xa8.0x01.0x01 -> 192.168.1.1
            // - Decimal: 3232235777 -> 192.168.1.1
            // - Octal: 0300.0250.0001.0001 -> 192.168.1.1
            // While these still resolve to private IPs, we reject exotic notations to:
            // 1. Prevent confusion about what formats are allowed
            // 2. Guard against future URL parser behavior changes
            // 3. Enforce explicit, readable configuration
            const rawHostname = url.hostname;

            // Allow only standard formats: dotted-decimal IPv4, IPv6 (with brackets), or localhost
            // Reject: hex (0x), decimal (pure numbers), octal (leading zeros), domain names
            const isStandardIPv4Format =
              /^([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})$/.test(rawHostname);
            const isIPv6Format = rawHostname.includes(':'); // IPv6 contains colons
            const isLocalhost =
              rawHostname === 'localhost' || rawHostname === '127.0.0.1' || rawHostname === '::1';

            if (!isStandardIPv4Format && !isIPv6Format && !isLocalhost) {
              console.warn(
                `⚠️  DEV_API_URL hostname '${rawHostname}' is not in standard format.\n` +
                  '   Only standard dotted-decimal IPv4 (e.g., 192.168.1.1) is allowed.\n' +
                  '   Exotic formats (hex 0xc0.0xa8.0x1.0x1, decimal 3232235777, octal) are rejected.\n' +
                  '   Using localhost only for cleartext exceptions.'
              );
              // Skip adding this host to cleartext exceptions
              throw new Error('Non-standard hostname format');
            }

            // SECURITY: Strip IPv6 brackets from url.hostname
            // Node's URL parser returns IPv6 addresses WITH brackets: [::1], [fe80::1], etc.
            // These brackets are invalid in Android XML and must be removed
            // Only strip if it's actually IPv6 (contains colon after bracket removal)
            let hostname = rawHostname;
            if (hostname.startsWith('[') && hostname.endsWith(']')) {
              const stripped = hostname.slice(1, -1);
              if (stripped.includes(':')) {
                hostname = stripped;
              }
              // If no colon, leave brackets (malformed input like [192.168.1.1] will fail validation)
            }

            // Only add cleartext exception if:
            // 1. Protocol is HTTP (not HTTPS - HTTPS doesn't need cleartext permission)
            // 2. Hostname is valid and non-empty
            // 3. Hostname is not localhost/loopback (already covered in base localhost config)
            // 4. Hostname is a private IPv4 or IPv6 address - prevents domain name bypass
            if (
              url.protocol === 'http:' &&
              hostname &&
              hostname !== 'localhost' &&
              hostname !== '127.0.0.1' &&
              hostname !== '::1'
            ) {
              // SECURITY: Validate that hostname is a private IPv4 address
              // IPv6 is NOT supported in DEV_API_URL (complexity/edge cases - use localhost for IPv6)
              let isPrivateIP = false;
              let escapedHostname = '';

              // SECURITY FIX: Use [0-9] instead of \d to prevent Unicode decimal digit matching
              // \d matches Unicode decimal digits (e.g., Arabic-Indic ٠-٩), not just ASCII 0-9
              const ipv4Regex = /^([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})$/;
              const ipv4Match = hostname.match(ipv4Regex);

              if (ipv4Match) {
                // IPv4 validation
                const [, octet1, octet2, octet3, octet4] = ipv4Match;
                const octets = [octet1, octet2, octet3, octet4].map(Number);

                // SECURITY FIX: Validate Number() succeeded and octets are valid (0-255)
                // Prevents NaN issues and ensures proper numeric conversion
                if (octets.every(n => !isNaN(n) && n >= 0 && n <= 255)) {
                  // Check if it's RFC 1918 private IP
                  isPrivateIP =
                    octets[0] === 10 || // 10.0.0.0/8
                    (octets[0] === 172 && octets[1] >= 16 && octets[1] <= 31) || // 172.16.0.0/12
                    (octets[0] === 192 && octets[1] === 168); // 192.168.0.0/16

                  if (!isPrivateIP) {
                    console.warn(
                      `⚠️  DEV_API_URL hostname '${hostname}' is not a private IPv4 address. ` +
                        'Only RFC 1918 private IPs (10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16) ' +
                        'are allowed in cleartext exceptions. Using localhost only.'
                    );
                  }
                } else {
                  console.warn(
                    `⚠️  Invalid IPv4 address in DEV_API_URL: ${hostname} (invalid octet format or out of range 0-255)`
                  );
                }
              } else if (hostname.includes(':')) {
                // IPv6 NOT SUPPORTED for DEV_API_URL
                // Reason: IPv6 validation is complex (zone IDs, embedded IPv4, etc.) and error-prone
                // Solution: Use localhost (which includes ::1) for IPv6 development
                console.warn(
                  `⚠️  IPv6 addresses not supported in DEV_API_URL: ${hostname}\n` +
                    '   For IPv6 development, use DEV_API_URL=http://localhost:8787 (includes ::1 support).\n' +
                    '   Using localhost only for cleartext exceptions.'
                );
              } else {
                // Not IPv4 or IPv6 - likely a domain name (blocked)
                console.warn(
                  `⚠️  DEV_API_URL hostname '${hostname}' is not a valid IPv4 address. ` +
                    'Only private IPv4 addresses are allowed in development cleartext exceptions. ' +
                    'For IPv6 or domain names, use localhost. Using localhost only.'
                );
              }

              // If validation passed, add to cleartext exceptions
              if (isPrivateIP) {
                // SECURITY: XML escape hostname to prevent injection
                // Attack: DEV_API_URL="http://10.0.0.1</domain><domain>evil.com"
                escapedHostname = hostname
                  .replace(/&/g, '&amp;')
                  .replace(/</g, '&lt;')
                  .replace(/>/g, '&gt;')
                  .replace(/"/g, '&quot;')
                  .replace(/'/g, '&apos;');

                devHost = `\n        <domain includeSubdomains="false">${escapedHostname}</domain>`;
                devHostDisplayName = hostname;
              }
            }
          } catch (e) {
            console.warn(`⚠️  Invalid DEV_API_URL: ${devApiUrl} - using localhost only`);
          }
        }

        networkSecurityConfig = `<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <base-config cleartextTrafficPermitted="false">
        <trust-anchors>
            <certificates src="system" />
        </trust-anchors>
    </base-config>

    <!-- Development/Staging exception for localhost API access ONLY -->
    <!-- Required for DEV_API_URL connecting to local development server -->
    <!-- Includes IPv4 (127.0.0.1) and IPv6 (::1) localhost addresses -->
    <!-- Android emulator uses 10.0.2.2 to access host machine's localhost -->
    <domain-config cleartextTrafficPermitted="true">
        <domain includeSubdomains="false">localhost</domain>
        <domain includeSubdomains="false">127.0.0.1</domain>
        <domain includeSubdomains="false">::1</domain>
        <domain includeSubdomains="false">10.0.2.2</domain>${devHost}
    </domain-config>
</network-security-config>
`;
        console.log(
          `✓ Network security config: ${appVariant} mode (allows localhost${devHostDisplayName ? ` + ${devHostDisplayName}` : ''})`
        );
      }

      // Write the environment-appropriate configuration
      try {
        fs.writeFileSync(networkSecurityConfigPath, networkSecurityConfig, 'utf-8');
      } catch (error) {
        throw new Error(
          `Failed to write network security config to ${networkSecurityConfigPath}.\n` +
            `Error: ${error.message}\n` +
            'This may indicate a permissions issue or disk space problem.'
        );
      }

      return config;
    },
  ]);

  // Step 6: Update AndroidManifest.xml to reference network security config
  config = withAndroidManifest(config, config => {
    // Safely access AndroidManifest structure with null checks
    if (!config.modResults?.manifest?.application?.[0]) {
      throw new Error(
        'Invalid AndroidManifest.xml structure - missing application element. ' +
          'This may indicate a corrupted manifest or incompatible Expo version.\n\n' +
          'Recovery steps:\n' +
          '1. Run: npx expo prebuild --clean --platform android\n' +
          '2. If still failing, run: npx expo-doctor\n' +
          '3. Check for breaking changes in your Expo SDK version'
      );
    }

    const mainApplication = config.modResults.manifest.application[0];

    // Ensure the $ attribute object exists
    if (!mainApplication.$) {
      mainApplication.$ = {};
    }

    // Warn if attribute already exists (prevents silent overwrites)
    if (mainApplication.$['android:networkSecurityConfig']) {
      console.warn(
        '⚠️  android:networkSecurityConfig already set in AndroidManifest.xml - ' +
          'overwriting with @xml/network_security_config'
      );
    }

    // Add networkSecurityConfig attribute to <application> tag
    mainApplication.$['android:networkSecurityConfig'] = '@xml/network_security_config';

    return config;
  });

  return config;
}

module.exports = withAndroidBuildConfig;
