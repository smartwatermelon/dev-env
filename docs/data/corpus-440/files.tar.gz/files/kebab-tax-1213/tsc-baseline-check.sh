#!/usr/bin/env bash
# Ratchet wrapper around `tsc --noEmit` for the mobile package.
#
# Why this exists:
#   `tsc` has no `--max-errors` flag (unlike eslint's `--max-warnings`),
#   so the same Layer-1 ratchet pattern we use for the lint hook needs a
#   wrapper. The pre-commit hook and CI both invoke this script; both
#   block when the error count exceeds BASELINE.
#
# Ratchet protocol:
#   When you fix a batch of type errors, the script reports
#   "current < baseline — bump BASELINE in this script to lock in the win".
#   That is a manual step — auto-rewriting a tracked file from a hook would
#   create surprise diffs and confusing CI churn.
#
# Tracked alongside #1191's mobile-tsc burndown. When BASELINE reaches 0,
# replace this wrapper with `npx tsc --noEmit` directly in
# `mobile/package.json` and `.pre-commit-config.yaml`.

set -euo pipefail

# Pre-existing tsc error count on `main` at the time the hook was wired.
# Bump downward (never upward) as errors are fixed.
BASELINE=45

cd "$(dirname "$0")/.."

# Capture full output so we can both count errors AND show them on failure.
# `|| true` prevents `set -e` from exiting on tsc's non-zero return when
# errors are present — we want to inspect, not propagate yet.
TSC_OUTPUT=$(npx tsc --noEmit 2>&1 || true)
COUNT=$(printf '%s\n' "$TSC_OUTPUT" | grep -c "error TS" || true)

if [ "$COUNT" -gt "$BASELINE" ]; then
  printf '%s\n' "$TSC_OUTPUT"
  echo ""
  echo "✗ Mobile tsc: $COUNT errors (baseline: $BASELINE) — REGRESSION of $((COUNT - BASELINE))"
  echo "  Fix the new errors before committing. If you genuinely need to"
  echo "  raise the baseline, edit BASELINE in mobile/scripts/tsc-baseline-check.sh"
  echo "  and document why in the commit message."
  exit 1
fi

if [ "$COUNT" -lt "$BASELINE" ]; then
  echo "✓ Mobile tsc: $COUNT errors (baseline: $BASELINE — bump baseline in mobile/scripts/tsc-baseline-check.sh to lock this in)"
  exit 0
fi

echo "✓ Mobile tsc: $COUNT errors (matches baseline)"
exit 0
