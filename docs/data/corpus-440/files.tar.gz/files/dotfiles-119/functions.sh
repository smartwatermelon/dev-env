# ~/.config/bash/functions.sh
#shellcheck shell=bash
# Shell functions

# Command-line entry point to pre-commit linter
lint() {
  local cfg="${HOME}/.config/pre-commit/config.yaml"

  # Check if config file exists
  if [[ ! -f "${cfg}" ]]; then
    echo "Error: Pre-commit config not found at ${cfg}" >&2
    return 1
  fi

  # Check if we're in a git repository
  local in_git_repo=false
  if git rev-parse --is-inside-work-tree &>/dev/null; then
    in_git_repo=true
  fi

  if [[ $# -eq 0 ]]; then
    # No arguments → run on all files
    if [[ "${in_git_repo}" == "true" ]]; then
      pre-commit run --all-files --config "${cfg}"
      return $?
    else
      echo "Error: --all-files requires being in a git repository" >&2
      echo "Usage: lint <file1> [file2] ... (specify files when outside git repo)" >&2
      return 1
    fi
  fi

  # Arguments given → expand globs and get absolute paths
  local files=()
  shopt -s nullglob globstar
  for f in "$@"; do
    # following ${f} should NOT be quoted (SC2066)
    for g in ${f}; do
      if [[ -f "${g}" ]]; then
        # Convert to absolute path to handle temp directory operations
        files+=("$(realpath "${g}")")
      fi
    done
  done
  shopt -u nullglob globstar

  if [[ ${#files[@]} -eq 0 ]]; then
    echo "No files matched the patterns: $*" >&2
    return 1
  fi

  if [[ "${in_git_repo}" == "true" ]]; then
    # In git repo - run directly
    pre-commit run --files "${files[@]}" --config "${cfg}"
    return $?
  else
    # Not in git repo - create temporary git repo
    local temp_dir
    temp_dir=$(mktemp -d)
    local result=0
    local original_dir
    original_dir=$(pwd)

    # Cleanup function
    # Use ${var:-} for set -u safety — locals are out of scope when EXIT trap fires
    cleanup_temp_repo() {
      cd "${original_dir:-}" 2>/dev/null || true
      rm -rf "${temp_dir:-}"
      trap - EXIT # Unset trap
    }
    trap cleanup_temp_repo EXIT

    # Initialize git repo in temp directory
    cd "${temp_dir}" || {
      echo "Error: Failed to enter temp directory" >&2
      return 1
    }

    git init --quiet || {
      echo "Error: Failed to initialize git repo" >&2
      return 1
    }

    # Configure git user (required for some hooks)
    git config user.name "lint-function"
    git config user.email "lint@example.com"

    # Copy files to temp repo and create relative path mapping
    local temp_files=()
    local file_mapping=()
    for file in "${files[@]}"; do
      local basename
      basename=$(basename "${file}")
      local temp_file="${temp_dir}/${basename}"

      # Handle filename conflicts by appending numbers
      local counter=1
      while [[ -f "${temp_file}" ]]; do
        local name="${basename%.*}"
        local ext="${basename##*.}"
        if [[ "${name}" == "${basename}" ]]; then
          # No extension
          temp_file="${temp_dir}/${basename}_${counter}"
        else
          temp_file="${temp_dir}/${name}_${counter}.${ext}"
        fi
        ((counter += 1))
      done

      cp -p "${file}" "${temp_file}" || {
        echo "Error: Failed to copy ${file}" >&2
        return 1
      }

      temp_files+=("$(basename "${temp_file}")")
      file_mapping+=("${temp_file}:${file}")
    done

    # Stage files (required by some hooks)
    git add .

    # Run pre-commit on the files
    pre-commit run --files "${temp_files[@]}" --config "${cfg}" || result=$?

    # Copy modified files back to original locations
    for mapping in "${file_mapping[@]}"; do
      local temp_file="${mapping%%:*}"
      local orig_file="${mapping##*:}"

      if [[ -f "${temp_file}" && "${temp_file}" -nt "${orig_file}" ]]; then
        echo "Copying fixes back to ${orig_file}"
        cp -p "${temp_file}" "${orig_file}"
      fi
    done

    # Cleanup and return to original directory
    cleanup_temp_repo
    return "${result}"
  fi
}
# Not exported - interactive command only

# Get Homebrew root based on installation location
_get_homebrew_root() {
  if [[ -d /opt/homebrew ]]; then
    echo "/opt/homebrew"
  else
    echo "/usr/local"
  fi
}
export -f _get_homebrew_root # Exported - may be used by subscripts

# Brew cask
cask() {
  brew "$@" --cask
}
# Not exported - interactive command only

# Remove quarantine attribute from files (macOS)
vax() {
  if [[ -z "$1" ]]; then
    echo "Usage: vax <file>" >&2
    return 1
  fi

  if [[ ! -e "$1" ]]; then
    echo "Error: File not found: $1" >&2
    return 1
  fi

  xattr -v -d com.apple.quarantine "$1"
}
# Not exported - interactive command only

# History search function
# Searches bash history for specified pattern(s)
hgrep() {
  local pattern="$1"

  if [[ -z "${pattern}" ]]; then
    echo "Usage: hgrep <pattern>"
    return 1
  fi

  # Use history command and pipe to grep with highlighting
  H="$(history)"
  grep --color=auto "${pattern}" <<<"${H}"
}
# Not exported - interactive command only

# Get name of parent script into variable
_what_is_this() {
  export THIS
  THIS=$(basename "${0}" 2>/dev/null || echo "script")
}
# Not exported - internal helper

# Send notification
_notif() {
  [[ -z "$1" ]] && return 0
  MSG="$1"
  _what_is_this

  # Always echo to terminal (important for seeing progress in output)
  echo "${THIS}: ${MSG}"

  # Also send desktop notification if tools available (skipped in SSH sessions)
  if command -v terminal-notifier &>/dev/null && command -v timeout &>/dev/null; then
    echo "${MSG}" | timeout 1 terminal-notifier -title "${THIS}" 2>/dev/null
  fi
}
# Not exported - internal helper

# Kill duplicate processes
# Safely kills other instances of a named process
# Usage: _kill_clones [process_name]
#   If no argument provided, uses ${THIS} from _what_is_this
_kill_clones() {
  local process_name="${1:-${THIS}}"
  local this_pid=$$

  # Safety check: refuse to kill critical system processes
  case "${process_name}" in
    bash | sh | zsh | fish | tcsh | csh | ksh | "" | "-bash" | "-sh" | "-zsh")
      echo "Error: _kill_clones refuses to kill shell processes: '${process_name}'" >&2
      return 1
      ;;
    *)
      # Process name is safe to kill
      ;;
  esac

  # Safety check: verify we're in a script context, not interactive shell
  if [[ "${process_name}" == "-"* ]] || [[ -z "${process_name}" ]]; then
    echo "Error: _kill_clones should only be used in scripts, not interactive shells" >&2
    return 1
  fi

  # Find and kill matching processes (excluding this one)
  local killed_count=0
  while IFS= read -r pid; do
    if [[ "${pid}" != "${this_pid}" ]] && [[ -n "${pid}" ]]; then
      _notif "killing ${pid}..."
      kill "${pid}" 2>/dev/null && ((killed_count += 1))
    fi
  done < <(pgrep -fl "${process_name}" | grep -v tail | awk '{print $1}' || true)

  if [[ ${killed_count} -gt 0 ]]; then
    _notif "Killed ${killed_count} clone(s) of ${process_name}"
  fi

  return 0
}
# Not exported - internal helper

# ============================================================================
# Package Manager Update Functions
# ============================================================================
# All update functions are exported to allow independent invocation
# (e.g., "_npm_update" to update only npm, "updates" to update all)
# Each function is self-sufficient: creates log directory, rotates log, handles errors

# Log rotation handled by logrotate (configured in /opt/homebrew/etc/logrotate.d/local-state-logs)
# Runs daily at 06:25 AM via launchd service (homebrew.mxcl.logrotate)

# Write update output to log file; also echo to terminal during interactive runs
# Prevents duplicate log entries when stdout is already redirected to the log
# (e.g. via LaunchAgent StandardOutPath)
_update_log() {
  if [[ -t 1 ]]; then
    tee -a "${HOME}/.local/state/updates.out"
  else
    cat >>"${HOME}/.local/state/updates.out"
  fi
}
# Not exported - internal helper

# Detect non-interactive invocation (e.g. LaunchAgent run overnight).
# In this mode, update functions must skip anything that would prompt for
# sudo / admin credentials / TouchID, since there's no user to respond and
# pam_tid surfaces a GUI dialog that pauses the whole run until login.
# Override with UPDATES_NONINTERACTIVE=1 to force this mode from a TTY
# (useful for testing), or UPDATES_NONINTERACTIVE=0 to force interactive.
_updates_noninteractive() {
  if [[ -n "${UPDATES_NONINTERACTIVE:-}" ]]; then
    [[ "${UPDATES_NONINTERACTIVE}" == "1" ]]
    return $?
  fi
  # No controlling TTY on stdin => LaunchAgent / cron / ssh-noninteractive
  [[ ! -t 0 ]]
}
# Not exported - internal helper

# Create a temporary directory containing a `sudo` shim that fails fast with
# a clear message instead of prompting. Echoes the directory path to stdout
# for the caller to prepend to PATH and to clean up when done.
# Intended for wrapping tools (e.g. `brew upgrade`) that invoke sudo for
# specific sub-operations (cask pkg installers) so those sub-operations
# fail individually while the rest of the run proceeds.
_updates_sudo_shim() {
  local shim_dir
  shim_dir=$(mktemp -d -t updates-sudo-shim) || return 1
  cat >"${shim_dir}/sudo" <<'SHIM'
#!/bin/bash
# Injected by _updates_sudo_shim during non-interactive `updates` run.
# Refuses to prompt the user; fails fast so the parent tool skips this op.
echo "sudo blocked (non-interactive updates): $*" >&2
exit 1
SHIM
  chmod +x "${shim_dir}/sudo" || {
    rm -rf "${shim_dir}"
    return 1
  }
  echo "${shim_dir}"
}
# Not exported - internal helper

# Update Homebrew packages
# Package managers provide their own network error diagnostics, so no pre-check needed
_homebrew_update() {
  local brew_prefix brew_owner my_id current_user
  brew_prefix="$(brew --prefix 2>/dev/null)" || { return 0; }
  brew_owner="$(stat -f '%u' "${brew_prefix}" 2>/dev/null)"
  my_id="$(id -u)"
  if [[ "${my_id}" != "${brew_owner}" ]]; then
    current_user="$(whoami)"
    _notif "Skipping Homebrew update: ${brew_prefix} is not owned by ${current_user}"
    return 0
  fi

  mkdir -p "${HOME}/.local/state" || return $?

  local timestamp output result
  timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

  _notif "Updating Homebrew..."
  # Note: tee failures are acceptable - output is shown to user even if logging fails
  echo "=== homebrew update ${timestamp} ===" | _update_log

  output=$(brew update --verbose 2>&1)
  result=$?
  echo "${output}" | _update_log
  if [[ "${result}" -ne 0 ]]; then
    _notif "brew update failed (exit ${result})"
    return "${result}"
  fi

  # Non-interactive mode (overnight LaunchAgent): upgrade formulae only and
  # defer ALL casks to the next interactive run. Casks such as tunnelblick
  # invoke `/usr/bin/sudo` by absolute path, which a PATH-based shim cannot
  # intercept; under pam_tid that surfaces a GUI TouchID prompt macOS defers
  # to unlock. Skipping casks removes that whole class of prompt. The sudo
  # shim is kept as defense-in-depth for a formula that shells out to a bare
  # `sudo`, and individual failures are tolerated so one bad formula does not
  # abort the unattended chain.
  local shim_dir=""
  local upgrade_path="${PATH}"
  local -a upgrade_args=(--verbose)
  local tolerate_upgrade_failure=false
  if _updates_noninteractive; then
    upgrade_args+=(--formula)
    tolerate_upgrade_failure=true
    shim_dir=$(_updates_sudo_shim) || shim_dir=""
    if [[ -n "${shim_dir}" ]]; then
      upgrade_path="${shim_dir}:${PATH}"
    else
      _notif "Warning: sudo shim unavailable - a sudo-invoking formula may prompt"
    fi
    _notif "Non-interactive: upgrading formulae only; casks deferred to next interactive run"
  fi

  output=$(PATH="${upgrade_path}" brew upgrade "${upgrade_args[@]}" 2>&1)
  result=$?
  echo "${output}" | _update_log
  [[ -n "${shim_dir}" ]] && rm -rf "${shim_dir}"
  if [[ "${result}" -ne 0 ]]; then
    if [[ "${tolerate_upgrade_failure}" == "true" ]]; then
      _notif "brew upgrade (formulae) completed with errors (exit ${result}) - check log"
    else
      _notif "brew upgrade failed (exit ${result})"
      return "${result}"
    fi
  fi

  output=$(brew cleanup --prune=all -s 2>&1)
  result=$?
  echo "${output}" | _update_log
  if [[ "${result}" -ne 0 ]]; then
    _notif "brew cleanup failed (exit ${result})"
    return "${result}"
  fi

  # brew doctor often returns non-zero for warnings; log but don't fail
  output=$(brew doctor 2>&1)
  result=$?
  echo "${output}" | _update_log
  if [[ "${result}" -eq 0 ]]; then
    _notif "Homebrew update completed successfully"
  else
    _notif "Homebrew update completed with warnings (check log)"
  fi

  return 0
}
# Not exported - internal helper

# Update global npm packages
# Returns 0 (success) if npm is not installed to allow graceful degradation
_npm_update() {
  if ! command -v npm &>/dev/null; then
    _notif "npm not found, skipping"
    return 0 # Not an error - npm is optional
  fi

  mkdir -p "${HOME}/.local/state" || return $?

  local timestamp output result
  timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

  _notif "Updating npm packages..."
  echo "=== npm update ${timestamp} ===" | _update_log

  output=$(npm update -g --verbose 2>&1)
  result=$?
  echo "${output}" | _update_log

  if [[ "${result}" -eq 0 ]]; then
    _notif "npm update completed"
  else
    _notif "npm update failed (exit ${result})"
  fi
  return "${result}"
}
# Not exported - internal helper

# Update pipx packages
# Returns 0 (success) if pipx is not installed to allow graceful degradation
_pipx_update() {
  if ! command -v pipx &>/dev/null; then
    _notif "pipx not found, skipping"
    return 0 # Not an error - pipx is optional
  fi

  mkdir -p "${HOME}/.local/state" || return $?

  local timestamp output result
  timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

  _notif "Updating pipx packages..."
  echo "=== pipx update ${timestamp} ===" | _update_log

  # headroom-ai is installed as an editable local fork with a maturin (Rust)
  # build backend; PyO3 needs this flag to build on Python > 3.13.
  output=$(PYO3_USE_ABI3_FORWARD_COMPATIBILITY=1 pipx upgrade-all --verbose 2>&1)
  result=$?
  echo "${output}" | _update_log

  if [[ "${result}" -eq 0 ]]; then
    _notif "pipx update completed"
  else
    _notif "pipx update failed (exit ${result})"
  fi
  return "${result}"
}
# Not exported - internal helper

# Update Ruby gems
# Returns 0 (success) if gem is not installed to allow graceful degradation
_gem_update() {
  if ! command -v gem &>/dev/null; then
    _notif "gem not found, skipping"
    return 0 # Not an error - gem is optional
  fi

  mkdir -p "${HOME}/.local/state" || return $?

  local timestamp output result
  timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

  _notif "Updating Ruby gems..."
  echo "=== gem update ${timestamp} ===" | _update_log

  output=$(gem update --verbose 2>&1)
  result=$?
  echo "${output}" | _update_log

  if [[ "${result}" -ne 0 ]]; then
    _notif "gem update failed (exit ${result})"
    return "${result}"
  fi

  # gem cleanup is non-critical - warn on failure but don't fail overall
  output=$(gem cleanup --verbose 2>&1)
  local cleanup_result=$?
  echo "${output}" | _update_log

  if [[ "${cleanup_result}" -eq 0 ]]; then
    _notif "gem update and cleanup completed"
  else
    _notif "gem update succeeded, but cleanup failed (exit ${cleanup_result}) - check log"
  fi

  return 0 # Return success since update succeeded (cleanup failure is non-critical)
}
# Not exported - internal helper

# Update macOS system software
# Prompts for admin credentials via system dialog if needed
# Returns non-zero on failure (fail-fast)
_softwareupdate() {
  if ! command -v softwareupdate &>/dev/null; then
    _notif "softwareupdate not found, skipping"
    return 0 # Not an error - macOS-specific tool
  fi

  mkdir -p "${HOME}/.local/state" || return $?

  local timestamp output result
  timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

  _notif "Updating macOS system software..."
  echo "=== softwareupdate ${timestamp} ===" | _update_log

  # In non-interactive mode, any step beyond listing can prompt for admin
  # credentials — observed in the wild: `softwareupdate --download --all`
  # prompts when a system-scope update (e.g. a macOS point release) is in
  # the list, because the downloader stages it into a privileged location.
  # Only `-l` is truly admin-free. Log what's pending and defer both
  # download and install to the next interactive `updates` run.
  if _updates_noninteractive; then
    _notif "Non-interactive: listing pending updates only (download/install deferred)"
    output=$(softwareupdate -l 2>&1)
    echo "${output}" | _update_log
    return 0 # Don't fail the chain - install deferred by design
  fi

  # Run softwareupdate without sudo - it will prompt for admin credentials if needed
  # Use pipefail to capture exit code, run directly to preserve TTY for auth prompts
  (
    set -o pipefail
    softwareupdate -i -a 2>&1 | _update_log
  )
  result=$?

  if [[ "${result}" -ne 0 ]]; then
    _notif "softwareupdate failed (exit ${result})"
    return "${result}" # Fail-fast
  else
    _notif "softwareupdate completed"
    return 0
  fi
}
# Not exported - internal helper

# Update Mac App Store applications
# Returns 0 (success) if mas is not installed to allow graceful degradation
# Fails fast if mas upgrade fails (including authentication issues)
_mas_update() {
  if [[ "${MAS_UPDATE_DISABLE:-}" == "true" ]]; then
    _notif "skipping mas per MAS_UPDATE_DISABLE"
    return 0
  fi

  if ! command -v mas &>/dev/null; then
    _notif "mas not found, skipping"
    return 0 # Not an error - mas is optional
  fi

  mkdir -p "${HOME}/.local/state" || return $?

  local timestamp output result
  timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

  _notif "Updating Mac App Store apps..."
  echo "=== mas update ${timestamp} ===" | _update_log

  # Note: mas account doesn't work on macOS 12+
  # Let mas upgrade fail naturally if not authenticated
  output=$(mas upgrade 2>&1)
  result=$?
  echo "${output}" | _update_log

  if [[ "${result}" -ne 0 ]]; then
    _notif "mas upgrade failed (exit ${result}) - check App Store authentication"
    return "${result}" # Fail-fast
  else
    _notif "mas upgrade completed"
    return 0
  fi
}
# Not exported - internal helper

# Update Claude Code CLI
# Returns 0 (success) if claude is not installed to allow graceful degradation
# Respects DISABLE_AUTOUPDATER=1 in ~/.claude/settings.json
_claude_update() {
  if ! command -v claude &>/dev/null; then
    _notif "claude not found, skipping"
    return 0 # Not an error - claude is optional
  fi

  # Check if autoupdater is disabled via settings
  local settings_file="${HOME}/.claude/settings.json"
  if [[ -f "${settings_file}" ]]; then
    if command -v jq &>/dev/null; then
      local disabled
      disabled=$(jq -r '.env.DISABLE_AUTOUPDATER // ""' "${settings_file}" 2>/dev/null)
      if [[ "${disabled}" == "1" ]]; then
        _notif "claude update disabled via settings, skipping"
        return 0
      fi
    else
      _notif "Warning: jq not installed, cannot check DISABLE_AUTOUPDATER setting"
    fi
  fi

  mkdir -p "${HOME}/.local/state" || return $?

  local timestamp binary_output binary_result
  timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

  _notif "Updating Claude Code..."
  echo "=== claude update ${timestamp} ===" | _update_log

  binary_output=$(claude update 2>&1)
  binary_result=$?
  echo "${binary_output}" | _update_log

  if [[ "${binary_result}" -eq 0 ]]; then
    _notif "claude update completed"
  else
    _notif "claude update failed (exit ${binary_result})"
    return "${binary_result}"
  fi

  # Update git-sourced Claude Code components (skills, hooks, etc.)
  # Best-effort — failure here does not affect the binary update result.
  local tools_script="${HOME}/.claude/scripts/update-tools.sh"
  if [[ -x "${tools_script}" ]]; then
    _notif "Updating Claude Code tools..."
    local tools_output tools_result
    tools_output=$("${tools_script}" 2>&1)
    tools_result=$?
    echo "${tools_output}" | _update_log
    if [[ "${tools_result}" -eq 0 ]]; then
      _notif "claude tools update completed"
    else
      _notif "claude tools update failed (exit ${tools_result})"
    fi
  fi

  return "${binary_result}"
}
# Not exported - internal helper

# Orchestrate all system updates
# Each updater function is self-sufficient and creates its own log directory
# Records the failing step to a state file so `updates --continue` can resume
# after the user fixes the underlying problem, instead of re-running steps
# that already succeeded (e.g. brew update/upgrade before a broken gem dir).
_UPDATES_STATE_FILE="${HOME}/.local/state/updates.progress"

updates() {
  local -a steps=(
    _homebrew_update
    _softwareupdate
    _mas_update
    _npm_update
    _pipx_update
    _gem_update
    _claude_update
  )
  local start_index=0

  if [[ -n "${1:-}" ]]; then
    if [[ "${1}" != "--continue" ]]; then
      _notif "Unknown option '${1}'; only --continue is supported"
      return 1
    fi

    if [[ -f "${_UPDATES_STATE_FILE}" ]]; then
      local last_failed i found=false
      last_failed=$(<"${_UPDATES_STATE_FILE}")
      for i in "${!steps[@]}"; do
        if [[ "${steps[i]}" == "${last_failed}" ]]; then
          start_index="${i}"
          found=true
          break
        fi
      done
      if [[ "${found}" == "true" ]]; then
        _notif "Resuming updates from ${last_failed}..."
      else
        _notif "State file references unknown step '${last_failed}'; running full updates"
      fi
    else
      _notif "No previous failure recorded; running full updates"
    fi

    # _homebrew_update defers casks to the next interactive run when the
    # prior invocation was non-interactive (e.g. the nightly LaunchAgent).
    # Skipping straight to a later step on --continue would silently drop
    # that catch-up forever, so always re-run it (idempotent, cheap) unless
    # it's already covered by the normal loop below.
    if ((start_index > 0)); then
      _notif "Re-running Homebrew update to pick up any casks deferred by a non-interactive run..."
      _homebrew_update || return $?
    fi
  fi

  _notif "Starting system updates..."

  local i step result
  for ((i = start_index; i < ${#steps[@]}; i++)); do
    step="${steps[i]}"
    "${step}"
    result=$?
    if [[ "${result}" -ne 0 ]]; then
      if ! mkdir -p "${HOME}/.local/state" || ! echo "${step}" >"${_UPDATES_STATE_FILE}"; then
        _notif "Warning: could not save resume state; 'updates --continue' will run from the start"
      fi
      _notif "updates stopped at ${step} (exit ${result}); fix the issue and run 'updates --continue'"
      return "${result}"
    fi
  done

  rm -f "${_UPDATES_STATE_FILE}"
  _notif "All updates completed successfully"
  return 0
}
# Not exported - interactive command only

# Update all local repos, repair local config symlinks, run software updates
# pull-my-repos and pull-beacon-repos are from ~/Developer/scripts, symlinked into ~/.local/bin
allup() {
  if command -v pull-my-repos &>/dev/null; then pull-my-repos || return $?; fi
  if command -v pull-beacon-repos &>/dev/null; then pull-beacon-repos || return $?; fi
  "${HOME}/Developer/dotfiles/install.sh" --repair || return $?
  "${HOME}/Developer/claude-config/install.sh" --repair || return $?
  updates "$@"
}
# Not exported - interactive command only

# Extract compressed files (handles multiple formats)
extract() {
  if [[ -f "$1" ]]; then
    case "$1" in
      *.tar.bz2) tar xjf "$1" ;;
      *.tar.gz) tar xzf "$1" ;;
      *.tar.xz) tar xJf "$1" ;;
      *.bz2) bunzip2 "$1" ;;
      *.rar) unrar x "$1" ;;
      *.gz) gunzip "$1" ;;
      *.tar) tar xf "$1" ;;
      *.tbz2) tar xjf "$1" ;;
      *.tgz) tar xzf "$1" ;;
      *.zip) unzip "$1" ;;
      *.Z) uncompress "$1" ;;
      *.7z) 7z x "$1" ;;
      *) echo "'$1' cannot be extracted via extract()" ;;
    esac
  else
    echo "'$1' is not a valid file"
  fi
}

# Create a new directory and enter it
mkcd() {
  mkdir -p "$1" && cd "$1" || return
}
# Not exported - interactive command only

# Jump to git repository root
cdroot() {
  local root
  root=$(git rev-parse --show-toplevel 2>/dev/null)
  if [[ -n "${root}" ]]; then
    cd "${root}" || return
  else
    echo "Not in a git repository" >&2
    return 1
  fi
}
# Not exported - interactive command only

# Create and cd into a dated directory
mkdate() {
  local dir="${1:-$(date +%Y-%m-%d)}"
  mkdir -p "${dir}" && cd "${dir}" || return
}
# Not exported - interactive command only

# Toggle or set liquidprompt display mode
# Usage: lp_mode [single|multi|toggle]
# Default: toggle (when no argument provided)
lp_mode() {
  # Check if liquidprompt is loaded
  if ! type -t lp_theme &>/dev/null; then
    echo "Error: liquidprompt is not loaded" >&2
    return 1
  fi

  local mode="${1:-toggle}"

  case "${mode}" in
    single)
      LP_MARK_PREFIX=" "
      echo "Switched to single-line prompt"
      ;;
    multi | multiline)
      LP_MARK_PREFIX=$'\n'
      echo "Switched to multi-line prompt"
      ;;
    toggle)
      if [[ "${LP_MARK_PREFIX}" == " " ]]; then
        LP_MARK_PREFIX=$'\n'
        echo "Switched to multi-line prompt"
      else
        LP_MARK_PREFIX=" "
        echo "Switched to single-line prompt"
      fi
      ;;
    *)
      echo "Usage: lp_mode [single|multi|toggle]" >&2
      echo "  single   - Single-line prompt (default)" >&2
      echo "  multi    - Multi-line prompt ($ on own line)" >&2
      echo "  toggle   - Toggle between modes (default when no argument)" >&2
      return 1
      ;;
  esac
}
# Not exported - interactive command only

# ============================================================================
# Git CLI Wrapper
# ============================================================================
# Intercepts `git init` to trigger automatic .claude/ infrastructure creation
# All other git commands pass through unchanged
#
# SIMPLIFIED: Uses git rev-parse to find repo location, eliminating complex
# argument parsing. The init.templateDir already copies hooks, we just need
# to trigger post-checkout.

git() {
  # Guard against recursive calls
  if [[ -n "${_GIT_WRAPPER_ACTIVE:-}" ]]; then
    command git "$@"
    return $?
  fi

  # Run the real git command first
  command git "$@"
  local git_result=$?

  # Only proceed if command succeeded and was "git init"
  # Find subcommand, -C flag, and optional directory argument
  local is_init=false
  local init_dir=""
  local c_flag_dir=""
  local found_subcommand=false
  local next_is_c_arg=false

  for arg in "$@"; do
    # Capture argument after -C flag
    if [[ "${next_is_c_arg}" == "true" ]]; then
      c_flag_dir="${arg}"
      next_is_c_arg=false
      continue
    fi

    # Check for -C flag (git only supports "-C <path>" with space, not "-C<path>")
    if [[ "${arg}" == "-C" ]]; then
      next_is_c_arg=true
      continue
    fi

    # Skip other flags
    if [[ "${arg}" == -* ]]; then
      continue
    fi

    # First non-flag is the subcommand
    if [[ "${found_subcommand}" == "false" ]]; then
      [[ "${arg}" == "init" ]] && is_init=true
      found_subcommand=true
      continue
    fi

    # Second non-flag (after "init") is the directory
    if [[ "${is_init}" == "true" && -z "${init_dir}" ]]; then
      init_dir="${arg}"
      break
    fi
  done

  # Determine the target directory: -C flag takes precedence, then init_dir
  local target_dir=""
  if [[ -n "${c_flag_dir}" && -n "${init_dir}" ]]; then
    # Both -C and directory arg: combine them
    target_dir="${c_flag_dir}/${init_dir}"
  elif [[ -n "${c_flag_dir}" ]]; then
    # Just -C flag
    target_dir="${c_flag_dir}"
  elif [[ -n "${init_dir}" ]]; then
    # Just directory arg
    target_dir="${init_dir}"
  fi

  if ((git_result != 0)) || [[ "${is_init}" != "true" ]]; then
    return "${git_result}"
  fi

  # Set guard to prevent recursion in hooks
  # Exported so child processes (hooks) also bypass wrapper
  export _GIT_WRAPPER_ACTIVE=1

  # Save current directory if we need to change it
  local original_dir=""
  if [[ -n "${target_dir}" ]]; then
    original_dir=$(pwd)
  fi

  # Trap to cleanup guard and restore directory
  # Use ${var:-} for set -u safety — locals may be out of scope in inherited contexts
  trap 'unset _GIT_WRAPPER_ACTIVE; [[ -n "${original_dir:-}" ]] && cd "${original_dir:-}" 2>/dev/null || true' RETURN

  # If init created a repo in a different directory, cd there first
  # This makes git rev-parse work from inside the new repo
  if [[ -n "${target_dir}" ]]; then
    if ! cd "${target_dir}" 2>/dev/null; then
      echo "Error: Cannot cd to ${target_dir}" >&2
      return 1 # Return failure, not git_result
    fi
  fi

  # Let git tell us where the .git directory is
  # We're now inside the repo, so this returns ".git" (relative path)
  local git_dir
  git_dir=$(command git rev-parse --git-dir 2>/dev/null)

  if [[ -n "${git_dir}" ]]; then
    local post_checkout="${git_dir}/hooks/post-checkout"

    if [[ -x "${post_checkout}" ]]; then
      # Run hook with init parameters
      # Parameters: <prev-head> <new-head> <branch-checkout-flag>
      # Both SHAs are null since there are no commits yet after git init
      # Note: We're already in repo root, no need to cd again
      local null_sha="0000000000000000000000000000000000000000"
      if ! "${post_checkout}" "${null_sha}" "${null_sha}" 1; then
        echo "Warning: post-checkout hook execution failed" >&2
      fi
    fi
  fi

  return "${git_result}"
}
export -f git # Exported - overrides system git command globally

# ============================================================================
# GitHub CLI Wrapper
# ============================================================================
# Canonical implementation (including the identity auto-switch and the
# pre-merge review + REST/GraphQL merge-bypass blocking) lives in
# gh-wrapper.sh (sourced below), which also doubles as the standalone
# ~/.local/bin/gh wrapper when symlinked and executed directly. See that
# file for how the two modes interoperate.

if [[ -f "${HOME}/.config/bash/gh-wrapper.sh" ]]; then
  # shellcheck source=/dev/null
  source "${HOME}/.config/bash/gh-wrapper.sh"
else
  # Fail closed: a missing/broken symlink here (e.g. mid-install, or a
  # symlink-forest repair gone wrong) must not silently drop the
  # REST/GraphQL merge-bypass block and pre-merge review gate.
  echo "[gh] WARNING: ${HOME}/.config/bash/gh-wrapper.sh not found — gh merge guard is NOT active." >&2
  # install.sh --repair only re-links files that already exist as plain
  # copies; it skips paths that are missing entirely. A fully absent
  # gh-wrapper.sh needs the plain (non-repair) install.sh run.
  echo "[gh] Run install.sh to restore it." >&2
  gh() {
    echo "[gh] ERROR: gh-wrapper.sh is missing; refusing to run gh unguarded." >&2
    echo "[gh] Run install.sh to restore ${HOME}/.config/bash/gh-wrapper.sh." >&2
    return 1
  }
  export -f gh
fi

# ============================================================================
# gpush — Push, create PR, wait for CI, merge, and clean up in one command
# ============================================================================
# Usage: gpush [--no-merge]
#   --no-merge  Stop after CI passes (don't authorize or merge)
#
# Not exported — user-facing convenience function only

gpush() {
  # Validate arguments
  case "${1:-}" in
    --no-merge) ;;
    "") ;;
    *)
      echo "Usage: gpush [--no-merge]" >&2
      return 1
      ;;
  esac

  local no_merge=false
  if [[ "${1:-}" == "--no-merge" ]]; then
    no_merge=true
  fi

  local GREEN='\033[0;32m'
  local RED='\033[0;31m'
  local BLUE='\033[0;34m'
  local NC='\033[0m'

  # Step 1: Guard — refuse to run on main/master
  local branch
  branch=$(git symbolic-ref --short HEAD 2>/dev/null || echo "")
  if [[ -z "${branch}" || "${branch}" == "main" || "${branch}" == "master" ]]; then
    echo -e "${RED}[gpush]${NC} Refusing to run on ${branch:-detached HEAD}. Create a branch first." >&2
    return 1
  fi
  echo -e "${BLUE}[gpush]${NC} Branch: ${branch}"

  # Step 2: Push
  echo -e "${BLUE}[gpush]${NC} Pushing to origin..."
  if ! git push -u origin HEAD; then
    echo -e "${RED}[gpush]${NC} Push failed." >&2
    return 1
  fi

  # Step 3: Create PR (or detect existing one)
  local pr_number=""
  local pr_output
  echo -e "${BLUE}[gpush]${NC} Creating PR..."
  if pr_output=$(gh pr create --fill 2>&1); then
    # Extract PR number from URL in output (last line is typically the URL)
    pr_number=$(echo "${pr_output}" | grep -oE '/pull/[0-9]+' | tail -1 | grep -oE '[0-9]+')
    if [[ -z "${pr_number}" ]]; then
      echo -e "${RED}[gpush]${NC} Could not parse PR number from create output." >&2
      echo "${pr_output}" >&2
      return 1
    fi
    echo -e "${GREEN}[gpush]${NC} Created PR #${pr_number}"
  else
    # PR may already exist
    if echo "${pr_output}" | grep -qi "already exists"; then
      pr_number=$(gh pr view --json number -q .number 2>/dev/null)
      if [[ -n "${pr_number}" ]]; then
        echo -e "${BLUE}[gpush]${NC} PR #${pr_number} already exists, continuing"
      fi
    fi
    if [[ -z "${pr_number}" ]]; then
      echo -e "${RED}[gpush]${NC} Failed to create PR:" >&2
      echo "${pr_output}" >&2
      return 1
    fi
  fi

  # Step 4: Watch CI (use gh run watch — gh pr checks fails with PAT errors)
  # Anchor on the pushed commit SHA to avoid watching a stale run from a prior push.
  # A push can trigger multiple workflow runs (e.g. "Claude Blocking Review" +
  # "Dependabot Auto-Merge"). We fetch all runs for the commit, watch each one,
  # and skip runs whose workflow name matches ignorable_when_skipped when their
  # conclusion is "skipped" (e.g. Dependabot workflows on non-Dependabot branches).
  local head_sha
  head_sha=$(git rev-parse HEAD)
  echo -e "${BLUE}[gpush]${NC} Waiting for CI runs on ${head_sha:0:7}..."

  local ignorable_when_skipped=("Dependabot")
  local all_runs=""
  local attempts=0
  while [[ -z "${all_runs}" && ${attempts} -lt 15 ]]; do
    all_runs=$(gh run list --branch "${branch}" --commit "${head_sha}" --json databaseId,name -q '.[] | (.databaseId | tostring) + "\t" + .name' 2>/dev/null || true)
    if [[ -z "${all_runs}" ]]; then
      ((attempts += 1))
      sleep 2
    fi
  done
  if [[ -z "${all_runs}" ]]; then
    echo -e "${RED}[gpush]${NC} No CI runs found for ${head_sha:0:7} after 30s. Check GitHub Actions." >&2
    return 1
  fi

  # Re-poll after a short delay to catch late-registering workflows.
  # Only adopt the result if non-empty — a transient API failure must not
  # discard the known-good first poll.
  sleep 3
  local repoll
  repoll=$(gh run list --branch "${branch}" --commit "${head_sha}" --json databaseId,name -q '.[] | (.databaseId | tostring) + "\t" + .name' 2>/dev/null || true)
  if [[ -n "${repoll}" ]]; then
    all_runs=$(printf '%s\n%s\n' "${all_runs}" "${repoll}" | sort -u -t$'\t' -k1,1)
  fi

  local ci_passed=false
  local ci_failed=false
  local fail_detail=""
  local run_id run_name pattern
  while IFS=$'\t' read -r run_id run_name; do
    [[ -z "${run_id}" ]] && continue
    echo -e "${BLUE}[gpush]${NC} Watching run ${run_id} (${run_name})..."
    gh run watch "${run_id}" >/dev/null 2>&1 || true

    local run_conclusion
    run_conclusion=$(gh run view "${run_id}" --json conclusion --jq '.conclusion') || {
      echo -e "${RED}[gpush]${NC} Failed to query run ${run_id} status." >&2
      return 1
    }

    if [[ "${run_conclusion}" == "success" ]]; then
      echo -e "${GREEN}[gpush]${NC} Passed: ${run_name}"
      ci_passed=true
    elif [[ "${run_conclusion}" == "skipped" ]]; then
      local ignorable=false
      for pattern in "${ignorable_when_skipped[@]}"; do
        if [[ "${run_name}" == *"${pattern}"* ]]; then
          ignorable=true
          break
        fi
      done
      if [[ "${ignorable}" == true ]]; then
        echo -e "${BLUE}[gpush]${NC} Ignoring skipped run: ${run_name}"
      else
        ci_failed=true
        fail_detail+="${run_name}: ${run_conclusion}; "
      fi
    else
      ci_failed=true
      fail_detail+="${run_name}: ${run_conclusion}; "
    fi
  done <<<"${all_runs}"

  if [[ "${ci_failed}" == true ]]; then
    fail_detail="${fail_detail%; }"
    echo -e "${RED}[gpush]${NC} CI failed (${fail_detail}). Fix and re-run gpush." >&2
    return 1
  fi
  if [[ "${ci_passed}" == false ]]; then
    echo -e "${RED}[gpush]${NC} No CI runs succeeded (all were skipped). Check GitHub Actions." >&2
    return 1
  fi
  echo -e "${GREEN}[gpush]${NC} CI passed"

  if [[ "${no_merge}" == true ]]; then
    echo -e "${GREEN}[gpush]${NC} --no-merge: stopping after CI. PR #${pr_number} is ready."
    return 0
  fi

  # Step 5: Confirm and authorize merge
  local confirm
  echo ""
  read -r -p "[gpush] Merge PR #${pr_number}? [y/N] " confirm
  if [[ ! "${confirm}" =~ ^[Yy]$ ]]; then
    echo -e "${BLUE}[gpush]${NC} Merge cancelled. PR #${pr_number} is ready for manual merge."
    return 0
  fi

  if ! command -v merge-lock &>/dev/null; then
    echo -e "${RED}[gpush]${NC} merge-lock not found on PATH." >&2
    return 1
  fi
  if ! merge-lock auth "${pr_number}" "gpush"; then
    echo -e "${RED}[gpush]${NC} merge-lock authorization failed." >&2
    return 1
  fi

  # Step 6: Merge (goes through gh wrapper → pre-merge-review.sh)
  echo -e "${BLUE}[gpush]${NC} Merging PR #${pr_number}..."
  if ! gh pr merge "${pr_number}" --squash --delete-branch; then
    echo -e "${RED}[gpush]${NC} Merge failed. Check pre-merge review output above." >&2
    return 1
  fi
  echo -e "${GREEN}[gpush]${NC} PR #${pr_number} merged"

  # Step 7: Cleanup — handle each step independently
  local default_branch
  default_branch=$(git remote show origin 2>/dev/null | awk '/HEAD branch/ {print $NF}')
  default_branch="${default_branch:-main}"
  echo -e "${BLUE}[gpush]${NC} Cleaning up..."
  if ! git switch "${default_branch}"; then
    echo -e "${RED}[gpush]${NC} Failed to switch to ${default_branch}." >&2
    return 1
  fi
  if ! git pull; then
    echo -e "${RED}[gpush]${NC} Failed to pull ${default_branch}. Run 'git pull' manually." >&2
    return 1
  fi
  git branch -D "${branch}" 2>/dev/null || true
  echo -e "${GREEN}[gpush]${NC} Done. Back on ${default_branch}."
}

# ============================================================================
# 1Password Helper
# ============================================================================
# opp — run op as personal account, bypassing the service account token.
# In interactive shells, OP_SERVICE_ACCOUNT_TOKEN is not set so this is
# equivalent to plain op. Inside CCCLI sessions (where the wrapper has set
# OP_SERVICE_ACCOUNT_TOKEN), this provides Personal vault access.

opp() {
  (
    unset OP_SERVICE_ACCOUNT_TOKEN
    if ! op whoami &>/dev/null; then
      #      eval "$(op signin)"
      local signin_cmd
      signin_cmd=$(op signin) || return $?
      eval "${signin_cmd}"
    fi
    op "$@"
  )
}
export -f opp # Exported - available inside CCCLI sessions
